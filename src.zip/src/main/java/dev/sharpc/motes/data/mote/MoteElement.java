package dev.sharpc.motes.data.mote;

public enum MoteElement
{
    FIRE,
    WATER,
    EARTH,
    WIND,
    DARK,
    LIGHT
}
